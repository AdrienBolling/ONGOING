# ONGOING
Continuous Knowledge Modelling library
